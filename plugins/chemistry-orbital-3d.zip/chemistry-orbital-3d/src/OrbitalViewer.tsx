import { useEffect, useRef, useState, useCallback } from 'react'

interface A2UINode {
  properties?: Record<string, unknown>
}

declare const THREE: any

function parseStr(val: unknown, fallback: string): string {
  return typeof val === 'string' ? val : fallback
}
function parseNum(val: unknown, fallback: number): number {
  const n = Number(val)
  return Number.isFinite(n) ? n : fallback
}

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) { resolve(); return }
    const s = document.createElement('script')
    s.src = src
    s.onload = () => resolve()
    s.onerror = () => reject(new Error('Failed to load ' + src))
    document.head.appendChild(s)
  })
}

// ===== Quantum mechanics math =====

function factorial(n: number): number {
  if (n <= 1) return 1
  let r = 1
  for (let i = 2; i <= n; i++) r *= i
  return r
}

function associatedLaguerre(n: number, alpha: number, x: number): number {
  if (n === 0) return 1
  if (n === 1) return 1 + alpha - x
  let L0 = 1, L1 = 1 + alpha - x, L2 = 0
  for (let k = 2; k <= n; k++) {
    L2 = ((2 * k - 1 + alpha - x) * L1 - (k - 1 + alpha) * L0) / k
    L0 = L1; L1 = L2
  }
  return L2
}

function associatedLegendre(l: number, m: number, x: number): number {
  const absM = Math.abs(m)
  if (absM > l) return 0
  let pmm = 1.0
  if (absM > 0) {
    const somx2 = Math.sqrt((1 - x) * (1 + x))
    let fact = 1.0
    for (let i = 1; i <= absM; i++) { pmm *= -fact * somx2; fact += 2.0 }
  }
  if (l === absM) return pmm
  let pmmp1 = x * (2 * absM + 1) * pmm
  if (l === absM + 1) return pmmp1
  let pll = 0
  for (let ll = absM + 2; ll <= l; ll++) {
    pll = ((2 * ll - 1) * x * pmmp1 - (ll + absM - 1) * pmm) / (ll - absM)
    pmm = pmmp1; pmmp1 = pll
  }
  return pll
}

function getRadialWavefunction(n: number, l: number, r: number, Z: number): number {
  const a0 = 1.0
  const rho = (2 * Z * r) / (n * a0)
  const coeff = Math.sqrt(Math.pow(2 * Z / (n * a0), 3) * factorial(n - l - 1) / (2 * n * factorial(n + l)))
  return coeff * Math.pow(rho, l) * Math.exp(-rho / 2) * associatedLaguerre(n - l - 1, 2 * l + 1, rho)
}

function getSphericalHarmonic(l: number, m: number, type: string | undefined, theta: number, phi: number): number {
  const ct = Math.cos(theta), st = Math.sin(theta)
  if (type) {
    if (l === 0) return 1 / Math.sqrt(4 * Math.PI)
    if (l === 1) {
      if (type === 'x') return Math.sqrt(3 / (4 * Math.PI)) * st * Math.cos(phi)
      if (type === 'y') return Math.sqrt(3 / (4 * Math.PI)) * st * Math.sin(phi)
      if (type === 'z') return Math.sqrt(3 / (4 * Math.PI)) * ct
    } else if (l === 2) {
      if (type === 'z2') return Math.sqrt(5 / (16 * Math.PI)) * (3 * ct * ct - 1)
      if (type === 'xz') return Math.sqrt(15 / (4 * Math.PI)) * st * ct * Math.cos(phi)
      if (type === 'yz') return Math.sqrt(15 / (4 * Math.PI)) * st * ct * Math.sin(phi)
      if (type === 'xy') return Math.sqrt(15 / (4 * Math.PI)) * st * st * Math.sin(phi) * Math.cos(phi)
      if (type === 'x2-y2') return Math.sqrt(15 / (16 * Math.PI)) * st * st * Math.cos(2 * phi)
    } else if (l === 3) {
      const s2 = st * st, c2 = ct * ct
      if (type === 'z3') return Math.sqrt(7 / (16 * Math.PI)) * (5 * c2 * ct - 3 * ct)
      if (type === 'xz2') return Math.sqrt(21 / (32 * Math.PI)) * (5 * c2 - 1) * st * Math.cos(phi)
      if (type === 'yz2') return Math.sqrt(21 / (32 * Math.PI)) * (5 * c2 - 1) * st * Math.sin(phi)
      if (type === 'xyz') return Math.sqrt(105 / (4 * Math.PI)) * s2 * ct * Math.sin(phi) * Math.cos(phi)
      if (type === 'z(x2-y2)') return Math.sqrt(105 / (16 * Math.PI)) * s2 * ct * Math.cos(2 * phi)
      if (type === 'x(x2-3y2)') return Math.sqrt(35 / (32 * Math.PI)) * s2 * st * (Math.cos(phi) * Math.cos(2 * phi) - Math.sin(phi) * Math.sin(2 * phi))
      if (type === 'y(3x2-y2)') return Math.sqrt(35 / (32 * Math.PI)) * s2 * st * (Math.sin(phi) * Math.cos(2 * phi) + Math.cos(phi) * Math.sin(2 * phi))
    }
  }
  const absM = Math.abs(m)
  const Plm = associatedLegendre(l, absM, ct)
  const norm = Math.sqrt((2 * l + 1) / (4 * Math.PI) * factorial(l - absM) / factorial(l + absM))
  if (m === 0) return norm * Plm
  return m > 0 ? norm * Plm * Math.cos(m * phi) * Math.sqrt(2) : norm * Plm * Math.sin(absM * phi) * Math.sqrt(2)
}

// ===== Orbital data =====

interface OrbitalDef {
  value: string; label: string; n: number; l: number; m: number; type?: string
  color1: string; color2: string
}

const orbitals: OrbitalDef[] = [
  { value: '1s', label: '1s', n: 1, l: 0, m: 0, color1: '#00ffff', color2: '#ff00ff' },
  { value: '2s', label: '2s', n: 2, l: 0, m: 0, color1: '#00ffff', color2: '#ff00ff' },
  { value: '2p_x', label: '2p_x', n: 2, l: 1, m: 1, type: 'x', color1: '#ff6b6b', color2: '#4ecdc4' },
  { value: '2p_y', label: '2p_y', n: 2, l: 1, m: 1, type: 'y', color1: '#ffe66d', color2: '#a8e6cf' },
  { value: '2p_z', label: '2p_z', n: 2, l: 1, m: 0, type: 'z', color1: '#ff6b9d', color2: '#c44569' },
  { value: '3s', label: '3s', n: 3, l: 0, m: 0, color1: '#00ffff', color2: '#ff00ff' },
  { value: '3p_x', label: '3p_x', n: 3, l: 1, m: 1, type: 'x', color1: '#ff6b6b', color2: '#4ecdc4' },
  { value: '3p_y', label: '3p_y', n: 3, l: 1, m: 1, type: 'y', color1: '#ffe66d', color2: '#a8e6cf' },
  { value: '3p_z', label: '3p_z', n: 3, l: 1, m: 0, type: 'z', color1: '#ff6b9d', color2: '#c44569' },
  { value: '3d_xy', label: '3d_xy', n: 3, l: 2, m: 2, type: 'xy', color1: '#ffa502', color2: '#ff6348' },
  { value: '3d_xz', label: '3d_xz', n: 3, l: 2, m: 1, type: 'xz', color1: '#1e90ff', color2: '#ff1493' },
  { value: '3d_yz', label: '3d_yz', n: 3, l: 2, m: 1, type: 'yz', color1: '#32cd32', color2: '#ff4500' },
  { value: '3d_x2-y2', label: '3d_x²-y²', n: 3, l: 2, m: 2, type: 'x2-y2', color1: '#9370db', color2: '#ffd700' },
  { value: '3d_z2', label: '3d_z²', n: 3, l: 2, m: 0, type: 'z2', color1: '#00ced1', color2: '#ff69b4' },
  { value: '4s', label: '4s', n: 4, l: 0, m: 0, color1: '#00ffff', color2: '#ff00ff' },
  { value: '4p_x', label: '4p_x', n: 4, l: 1, m: 1, type: 'x', color1: '#ff6b6b', color2: '#4ecdc4' },
  { value: '4p_y', label: '4p_y', n: 4, l: 1, m: 1, type: 'y', color1: '#ffe66d', color2: '#a8e6cf' },
  { value: '4p_z', label: '4p_z', n: 4, l: 1, m: 0, type: 'z', color1: '#ff6b9d', color2: '#c44569' },
  { value: '4d_xy', label: '4d_xy', n: 4, l: 2, m: 2, type: 'xy', color1: '#ffa502', color2: '#ff6348' },
  { value: '4d_xz', label: '4d_xz', n: 4, l: 2, m: 1, type: 'xz', color1: '#1e90ff', color2: '#ff1493' },
  { value: '4d_yz', label: '4d_yz', n: 4, l: 2, m: 1, type: 'yz', color1: '#32cd32', color2: '#ff4500' },
  { value: '4d_x2-y2', label: '4d_x²-y²', n: 4, l: 2, m: 2, type: 'x2-y2', color1: '#9370db', color2: '#ffd700' },
  { value: '4d_z2', label: '4d_z²', n: 4, l: 2, m: 0, type: 'z2', color1: '#00ced1', color2: '#ff69b4' },
  { value: '4f_z3', label: '4f_z³', n: 4, l: 3, m: 0, type: 'z3', color1: '#ff1493', color2: '#00ced1' },
  { value: '4f_xz2', label: '4f_xz²', n: 4, l: 3, m: 1, type: 'xz2', color1: '#ff6347', color2: '#4169e1' },
  { value: '4f_yz2', label: '4f_yz²', n: 4, l: 3, m: 1, type: 'yz2', color1: '#ffa500', color2: '#9370db' },
  { value: '4f_xyz', label: '4f_xyz', n: 4, l: 3, m: 1, type: 'xyz', color1: '#32cd32', color2: '#ff4500' },
  { value: '4f_z(x2-y2)', label: '4f_z(x²-y²)', n: 4, l: 3, m: 2, type: 'z(x2-y2)', color1: '#1e90ff', color2: '#ff1493' },
  { value: '4f_x(x2-3y2)', label: '4f_x(x²-3y²)', n: 4, l: 3, m: 3, type: 'x(x2-3y2)', color1: '#ff00ff', color2: '#00ffff' },
  { value: '4f_y(3x2-y2)', label: '4f_y(3x²-y²)', n: 4, l: 3, m: 3, type: 'y(3x2-y2)', color1: '#ffff00', color2: '#0000ff' },
]

// ===== Component =====

export default function OrbitalViewer({ node }: { node: A2UINode }) {
  const props = node.properties ?? {}
  const orbitalType = parseStr(props.orbital, '2p_z')
  const particleCountProp = parseNum(props.particleCount, 30000)

  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const engineRef = useRef<any>(null)

  const [ready, setReady] = useState(false)
  const [engineReady, setEngineReady] = useState(false)
  const [loading, setLoading] = useState(false)
  const [selectedOrbital, setSelectedOrbital] = useState(orbitalType)
  const [orbitalInfo, setOrbitalInfo] = useState<any>(null)

  // Load Three.js CDN
  useEffect(() => {
    loadScript('https://cdn.bootcdn.net/ajax/libs/three.js/r128/three.min.js')
      .then(() => loadScript('https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js'))
      .then(() => setReady(true))
  }, [])

  // Init Three.js scene
  const initScene = useCallback(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container || engineRef.current) return

    const W = container.clientWidth
    const H = container.clientHeight

    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x0a0a0a)
    scene.fog = new THREE.Fog(0x0a0a0a, 10, 50)

    const camera = new THREE.PerspectiveCamera(75, W / H, 0.1, 1000)
    camera.position.set(0, 0, 15)

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true })
    renderer.setSize(W, H)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

    const controls = new THREE.OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.05

    scene.add(new THREE.AmbientLight(0xffffff, 0.3))
    const pointLight = new THREE.PointLight(0xffffff, 1, 100)
    pointLight.position.set(5, 5, 5)
    scene.add(pointLight)

    // Nucleus
    const atom = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 32, 32),
      new THREE.MeshPhongMaterial({ color: 0xffffff, emissive: 0x444444, shininess: 100 })
    )
    scene.add(atom)

    // Axes
    const axisLen = 10, axisR = 0.01
    const makeAxis = (color: number, rx: number, ry: number) => {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(axisR, axisR, axisLen, 8), new THREE.MeshBasicMaterial({ color }))
      if (rx) m.rotation.x = rx
      if (ry) m.rotation.z = ry
      scene.add(m)
    }
    makeAxis(0xff0000, 0, Math.PI / 2)  // X
    makeAxis(0x00ff00, 0, 0)            // Y
    makeAxis(0x0000ff, Math.PI / 2, 0)  // Z

    let animId = 0
    const animate = () => {
      animId = requestAnimationFrame(animate)
      controls.update()
      renderer.render(scene, camera)
    }
    animId = requestAnimationFrame(animate)

    engineRef.current = { scene, camera, renderer, controls, animId }
    setEngineReady(true)
  }, [])

  // Init when ready
  useEffect(() => {
    if (!ready || !containerRef.current) return
    // Small delay to ensure container has dimensions
    const t = setTimeout(() => initScene(), 50)
    return () => clearTimeout(t)
  }, [ready, initScene])

  // Cleanup
  useEffect(() => {
    return () => {
      const e = engineRef.current
      if (e) {
        cancelAnimationFrame(e.animId)
        e.renderer.dispose()
        e.controls.dispose()
      }
    }
  }, [])

  // Generate orbital particles
  const generateOrbital = useCallback((orbitalValue: string, count: number) => {
    const e = engineRef.current
    if (!e) return

    setLoading(true)

    // Use setTimeout to not block UI
    setTimeout(() => {
      const orbital = orbitals.find(o => o.value === orbitalValue)
      if (!orbital) { setLoading(false); return }

      const { n, l, m, type, color1: c1, color2: c2 } = orbital
      const color1 = new THREE.Color(c1)
      const color2 = new THREE.Color(c2)
      const Z = 1, searchRadius = 8, scaleFactor = 1.0 / n

      const radialNodes = n - l - 1
      const angularNodes = l

      setOrbitalInfo({
        name: orbital.label,
        n, l, m,
        radialNodes, angularNodes,
        totalNodes: radialNodes + angularNodes,
        shellName: ['K', 'L', 'M', 'N', 'O', 'P', 'Q'][n - 1] || `n=${n}`,
        subshellName: ['s', 'p', 'd', 'f', 'g', 'h'][l] || `l=${l}`,
      })

      const positions: number[] = []
      const colors: number[] = []
      const sizes: number[] = []

      // Find max probability for rejection sampling
      let maxProb = 0
      for (let i = 0; i < 2000; i++) {
        const tr = Math.random() * searchRadius
        const tTheta = Math.acos(2 * Math.random() - 1)
        const tPhi = Math.random() * 2 * Math.PI
        const R = getRadialWavefunction(n, l, tr / scaleFactor, Z)
        const Y = getSphericalHarmonic(l, m, type, tTheta, tPhi)
        const prob = R * R * Y * Y * tr * tr
        if (prob > maxProb) maxProb = prob
      }

      let generated = 0, attempts = 0
      const maxAttempts = count * 1000

      while (generated < count && attempts < maxAttempts) {
        attempts++
        const r = Math.random() * searchRadius
        const theta = Math.acos(2 * Math.random() - 1)
        const phi = Math.random() * 2 * Math.PI
        const R = getRadialWavefunction(n, l, r / scaleFactor, Z)
        const Y = getSphericalHarmonic(l, m, type, theta, phi)
        const psi = R * Y
        const prob = psi * psi * r * r

        if (Math.random() * maxProb < prob) {
          positions.push(r * Math.sin(theta) * Math.cos(phi), r * Math.sin(theta) * Math.sin(phi), r * Math.cos(theta))
          const c = psi > 0 ? color1 : color2
          colors.push(c.r, c.g, c.b)
          sizes.push(0.05)
          generated++
        }
      }

      // Remove old particle system
      if (e.particleSystem) {
        e.scene.remove(e.particleSystem)
        e.particleSystem.geometry.dispose()
        e.particleSystem.material.dispose()
      }

      // Create glow texture
      const texCanvas = document.createElement('canvas')
      texCanvas.width = 64; texCanvas.height = 64
      const ctx = texCanvas.getContext('2d')!
      const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
      grad.addColorStop(0, 'rgba(255,255,255,1)')
      grad.addColorStop(0.4, 'rgba(255,255,255,0.9)')
      grad.addColorStop(0.7, 'rgba(255,255,255,0.4)')
      grad.addColorStop(0.9, 'rgba(255,255,255,0.1)')
      grad.addColorStop(1, 'rgba(255,255,255,0)')
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, 64, 64)
      const glowTexture = new THREE.CanvasTexture(texCanvas)

      const geometry = new THREE.BufferGeometry()
      geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
      geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
      geometry.setAttribute('size', new THREE.Float32BufferAttribute(sizes, 1))

      const material = new THREE.PointsMaterial({
        size: 0.06,
        vertexColors: true,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        sizeAttenuation: true,
        map: glowTexture,
      })

      const ps = new THREE.Points(geometry, material)
      e.scene.add(ps)
      e.particleSystem = ps

      setLoading(false)
    }, 30)
  }, [])

  // When orbital changes (from LLM or user selection)
  useEffect(() => {
    if (!engineReady || !selectedOrbital) return
    generateOrbital(selectedOrbital, particleCountProp)
  }, [selectedOrbital, engineReady, particleCountProp, generateOrbital])

  // Sync from LLM props
  useEffect(() => {
    if (orbitalType && orbitalType !== selectedOrbital) {
      setSelectedOrbital(orbitalType)
    }
  }, [orbitalType]) // eslint-disable-line react-hooks/exhaustive-deps

  const handleOrbitalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedOrbital(e.target.value)
  }

  const selectStyle: React.CSSProperties = {
    width: '100%', padding: '6px 8px', background: 'rgba(255,255,255,0.1)',
    border: '1px solid rgba(255,255,255,0.2)', borderRadius: 6,
    color: '#fff', fontSize: 13, fontFamily: 'Manrope, sans-serif', cursor: 'pointer',
  }

  const infoLabel: React.CSSProperties = { fontSize: 12, color: '#aaa' }
  const infoValue: React.CSSProperties = {
    fontSize: 12, color: '#fff', fontFamily: 'monospace',
    background: 'rgba(0,255,255,0.1)', padding: '2px 6px', borderRadius: 4,
  }

  return (
    <div style={{
      display: 'flex', gap: 0, borderRadius: 12, overflow: 'hidden',
      fontFamily: 'Manrope, sans-serif', color: '#1b1c1a',
    }}>
      {/* Controls sidebar */}
      <div style={{
        width: 200, background: 'rgba(20,20,20,0.95)', padding: 16,
        display: 'flex', flexDirection: 'column', gap: 12,
        borderRight: '1px solid rgba(255,255,255,0.1)',
      }}>
        <div style={{
          fontSize: 15, fontWeight: 600,
          background: 'linear-gradient(135deg, #00ffff 0%, #ff00ff 100%)',
          backgroundClip: 'text', WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}>
          原子轨道
        </div>

        <div>
          <div style={{ fontSize: 12, color: '#aaa', marginBottom: 4 }}>轨道类型</div>
          <select value={selectedOrbital} onChange={handleOrbitalChange} style={selectStyle}>
            {orbitals.map(o => (
              <option key={o.value} value={o.value} style={{ background: '#1a1a1a' }}>{o.label}</option>
            ))}
          </select>
        </div>

        {/* Orbital info */}
        {orbitalInfo && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 4 }}>
            {[
              ['名称', orbitalInfo.name],
              ['能层', `${orbitalInfo.shellName} (n=${orbitalInfo.n})`],
              ['能级', `${orbitalInfo.subshellName} (l=${orbitalInfo.l})`],
              ['径向节点', String(orbitalInfo.radialNodes)],
              ['角节点', String(orbitalInfo.angularNodes)],
              ['总节点', String(orbitalInfo.totalNodes)],
            ].map(([label, value]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={infoLabel}>{label}</span>
                <span style={infoValue}>{value}</span>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginTop: 'auto', fontSize: 11, color: '#555' }}>
          <div>拖动旋转 / 滚轮缩放</div>
        </div>
      </div>

      {/* 3D Canvas */}
      <div ref={containerRef} style={{
        flex: 1, position: 'relative', minWidth: 300, height: 360,
        background: '#0a0a0a',
      }}>
        <canvas ref={canvasRef} style={{ width: '100%', height: '100%', display: 'block' }} />

        {/* Loading overlay */}
        {loading && (
          <div style={{
            position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'rgba(10,10,10,0.8)', zIndex: 1,
          }}>
            <div style={{
              width: 36, height: 36,
              border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#00ffff',
              borderRadius: '50%', animation: 'spin 1s linear infinite',
            }} />
            <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
          </div>
        )}

        {!ready && (
          <div style={{
            position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 13, color: '#666',
          }}>
            加载 3D 引擎...
          </div>
        )}
      </div>
    </div>
  )
}
